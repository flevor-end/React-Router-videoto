import React from 'react';
function RegularError(props) {
  return (
    <h1 style={{color: 'white'}}>Ha ocurrido un error</h1>
  )
}

export default RegularError;
